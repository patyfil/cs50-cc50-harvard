// Counting

#include <stdbool.h>
#include <stdio.h>

int main(void)
{
    int i = 0;
    while (true)
    {
        printf("\r%i", i);
        i++;
    }
}
